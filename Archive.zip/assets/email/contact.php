<?php

$value = $_COOKIE["valid"];
$name = $_POST['name'];
$honey_name = $_POST['honey_name'];
$email = $_POST['email'];
$msg = $_POST['message'];

$isValid = $value == "false";

if($isValid == 1 || !empty($honey_name)) {
    echo "Something went wrong, please try again.";
    exit;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPmailer/src/Exception.php';
require '../PHPmailer/src/PHPMailer.php';
require '../PHPmailer/src/SMTP.php';

$mail = new PHPMailer();

$mail->Username = "mohanadarafework@gmail.com"; // your GMail user name
$mail->Password = "googlE91"; 
//-----------------------------------------------------------------------

$mail->isSMTP();
$mail->Host = "a2plcpnl0300.prod.iad2.secureserver.net";
$mail->SMTPSecure = "tsl";
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = 'hcugmalwku7r';
$mail->Password = 'googlE91!';

$mail->setFrom("marafe@live.com");
$mail->addAddress('mohanadarafework@gmail.com');
$mail->Subject = $subject;
$mail->Body = "You have received an email from ".$name.". \n\n".$msg;

if(!$mail->send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
else {
  echo "Message has been sent successfully";
}
?>

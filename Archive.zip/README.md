# Welcome to mohanadarafe.io

Welcome again for a brand new version of my personal website. Last year, I wrote a website of my CV from scratch & I wanted to take on the adventure once again.

### New things
In the past year, I have gained so much experience in school & work. I want to share my new skills with the public to help you get to know me